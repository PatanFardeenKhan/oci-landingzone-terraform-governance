
variable "network_compartment_ocids" {
  description = "JSON array string of compartment OCIDs"
  type        = string
}
