
locals {
  compartment_list = jsondecode(var.network_compartment_ocids)
}

data "oci_core_subnets" "subnets_by_compartment" {
  for_each       = toset(local.compartment_list)
  compartment_id = each.value
}

resource "oci_logging_log_group" "subnet_flow_logs_group" {
  compartment_id = local.compartment_list[0]
  display_name   = "subnet-flow-logs-group"
}

locals {
  all_subnets = merge([
    for c in data.oci_core_subnets.subnets_by_compartment :
    { for s in c.subnets : s.id => s if c.subnets != null }
  ]...)
}

resource "oci_logging_log" "subnet_flow_logs" {
  for_each = local.all_subnets

  display_name = "flowlog-${each.value.display_name}"
  log_group_id = oci_logging_log_group.subnet_flow_logs_group.id
  log_type     = "SERVICE"

  configuration {
    source {
      category    = "all"
      resource    = each.value.id
      service     = "flowlogs"
      source_type = "OCISERVICE"
    }
    compartment_id = each.value.compartment_id
  }

  is_enabled = true
}
